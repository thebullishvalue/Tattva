"""
Tattva — Shared CSS, chart theming, and color constants for the UI layer.
तत्त्व (Tattva) — "Principle / Essence"

UI — "Obsidian Quant" Institutional Research Terminal design language.

Aesthetic: "Obsidian Quant" — Institutional Research Terminal
-------------------------------------------------------------
Precision-instrument design language for quantitative finance.
- Display/UI:  Syne (geometric, authoritative, distinctive)
- Body/Data:   JetBrains Mono (refined monospace, tabular precision)
- Palette:     Obsidian (#0A0E17 -> #050810), Amber Gold (#D4A853),
               Cyan (#22D3EE), Emerald (#34D399), Rose (#FB7185)
- Surfaces:    Frameless glass panels with thin border strokes.
- Details:     Subtle gradient mesh, calibrated luminescence on signals,
               precision instrument aesthetic.
"""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from core.config import (
    CHART_BG,
    CHART_GRID,
    CHART_ZEROLINE,
    CHART_FONT_COLOR,
    COLOR_GREEN,
    COLOR_RED,
    COLOR_GOLD,
    COLOR_CYAN,
    COLOR_AMBER,
    COLOR_PURPLE,
    COLOR_MUTED,
    VERSION,        # single source of truth (re-exported for app.py imports)
    PRODUCT_NAME,
    COMPANY,
)

# Path to external CSS file
CSS_PATH = Path(__file__).parent / "theme.css"

# ── Shared Plotly layout config ─────────────────────────────────────────────
# Eliminates massive duplication across all tab files.

PLOTLY_FONT = dict(family="JetBrains Mono, monospace", color="#94A3B8", size=10)
PLOTLY_HOVERLABEL = dict(
    bgcolor="rgba(10, 14, 23, 0.95)",
    font=dict(family="JetBrains Mono, monospace", size=11, color="#F1F5F9"),
    bordercolor="rgba(255,255,255,0.08)",
    align="left",
)
PLOTLY_LEGEND = dict(
    orientation="h",
    yanchor="bottom",
    y=1.02,
    xanchor="right",
    x=1,
    font=dict(size=10, family="JetBrains Mono, monospace"),
    bgcolor="rgba(0,0,0,0)",
)
PLOTLY_MARGIN = dict(t=20, l=50, r=20, b=40)
PLOTLY_GRID = "rgba(255,255,255,0.035)"
PLOTLY_GRID_ZERO = "rgba(255,255,255,0.06)"

# Interactive chart config — click + zoom + pan
PLOTLY_MODEBAR = dict(
    modeBarButtonsToRemove=["lasso2d", "select2d"],
    modeBarButtonsToAdd=[
        "drawline",
        "eraseshape",
    ],
    displaylogo=False,
)


def chart_layout(
    height: int = 360,
    show_legend: bool = True,
    margin: dict | None = None,
    responsive: bool = False,
) -> dict:
    """Return a base Plotly layout dict for the Obsidian Quant theme.

    Args:
        height: Fixed pixel height for the chart.
        show_legend: Whether to show the legend.
        margin: Custom margin dict.
        responsive: If True, adds CSS-based responsive sizing via autosize.
    """
    base = dict(
        height=height,
        showlegend=show_legend,
        legend=PLOTLY_LEGEND if show_legend else None,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=PLOTLY_FONT,
        hovermode="x unified",
        hoverlabel=PLOTLY_HOVERLABEL,
        margin=margin or PLOTLY_MARGIN,
        spikedistance=-1,
    )
    if responsive:
        base["autosize"] = True
    return base


def style_axes(fig, y_title: str = "", x_title: str = "", y_range=None, row=None, col=None) -> None:
    """Apply consistent axis styling to a Plotly figure."""
    kw = {}
    if row is not None:
        kw["row"] = row
    if col is not None:
        kw["col"] = col

    fig.update_xaxes(
        showgrid=True,
        gridcolor=PLOTLY_GRID,
        gridwidth=0.5,
        zeroline=False,
        linecolor="rgba(255,255,255,0.04)",
        title_text=x_title,
        tickfont=dict(size=9, family="JetBrains Mono, monospace", color="#64748B"),
        # Vertical crosshair — dashed dim grey
        showspikes=True,
        spikemode="across",
        spikesnap="cursor",
        spikethickness=0.5,
        spikedash="dash",
        spikecolor="rgba(148,163,184,0.18)",
        **kw,
    )
    fig.update_yaxes(
        showgrid=True,
        gridcolor=PLOTLY_GRID,
        gridwidth=0.5,
        zeroline=True,
        zerolinecolor=PLOTLY_GRID_ZERO,
        zerolinewidth=0.5,
        linecolor="rgba(255,255,255,0.04)",
        title_text=y_title,
        range=y_range,
        tickfont=dict(size=9, family="JetBrains Mono, monospace", color="#64748B"),
        hoverformat=".2f",
        **kw,
    )
    # Backfill a 2-decimal hover on every visible trace. style_axes runs after
    # all traces are added and right before st.plotly_chart on every chart, so
    # this is the one place that fixes hover precision for ALL plots at once.
    apply_default_hover(fig)


def apply_default_hover(fig, precision: int = 2) -> None:
    """Give every visible trace a 2-decimal hover, robustly.

    We do NOT rely on a d3 number format inside the hovertemplate
    (``%{y:.2f}``): under ``hovermode="x unified"`` Plotly leaves that format
    UNAPPLIED and the hover leaks full float precision (e.g.
    "Consensus (50/50): -0.3687992004699925"). Instead the values are
    pre-formatted to strings in Python and stashed in ``customdata``, then the
    template just inserts the finished string (``%{customdata[0]}``) — no
    client-side number formatting involved, so it cannot be ignored.

    Idempotent-ish: skips ``hoverinfo="skip"`` fills. Traces that already carry
    a hover string via ``customdata`` (i.e. previously processed) are re-set
    safely. Keeps the marker ``text`` label (e.g. the hero "S. Buy"/"Hold") and
    the trace name when present.
    """
    for tr in fig.data:
        if getattr(tr, "hoverinfo", None) == "skip":
            continue
        # Preserve two kinds of intentional templates:
        #  • "%{x…}" — traces that show the X value on hover (e.g. the precedent
        #    Z-vs-forward scatter, "Z: %{x:.2f}"); those run in closest mode where
        #    d3 formats fine and the X is the point of the hover.
        #  • "%{customdata…}" — already pre-formatted (by us on a prior pass, so
        #    this stays idempotent across multi-row style_axes calls, or by a
        #    caller that wants a custom label with a clipped value).
        # Everything else (bare traces, and signal lines whose %{y:.2f} silently
        # fails under x-unified) we (re)format via customdata below.
        _ht = getattr(tr, "hovertemplate", None)
        if _ht and ("%{x" in _ht or "%{customdata" in _ht):
            continue
        y = getattr(tr, "y", None)
        if y is None:
            continue
        cd = []
        for v in y:
            try:
                if v is None or (isinstance(v, float) and v != v):
                    cd.append("—")
                else:
                    cd.append(f"{float(v):.{precision}f}")
            except (TypeError, ValueError):
                cd.append("—")           # non-numeric (category/text) → dash
        try:
            tr.customdata = [[s] for s in cd]
        except (ValueError, TypeError):
            continue
        has_text = getattr(tr, "text", None) is not None
        name = getattr(tr, "name", None)
        if has_text:
            tr.hovertemplate = "%{customdata[0]} · %{text}<extra></extra>"
        elif name:
            tr.hovertemplate = "%{fullData.name}: %{customdata[0]}<extra></extra>"
        else:
            tr.hovertemplate = "%{customdata[0]}<extra></extra>"


def inject_css() -> None:
    """Inject the Obsidian Quant Terminal CSS into the Streamlit app.

    Loads from external theme.css file for maintainability.
    Injects on every render — Streamlit deduplicates identical <style> blocks.
    """
    if CSS_PATH.exists():
        # Explicit UTF-8: theme.css embeds a Devanagari string (तत्त्व) in a
        # content: "..." rule. Path.read_text() with no encoding= falls back to
        # the OS locale encoding, which on many Windows machines is cp1252 (not
        # UTF-8) — that raises UnicodeDecodeError on the non-ASCII bytes and
        # crashes the app on startup before anything else can render.
        css = CSS_PATH.read_text(encoding="utf-8")
    else:
        css = "/* theme.css not found */"

    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def progress_bar(slot, pct: int, label: str, sub: str = "") -> None:
    """Render a themed progress card into an ``st.empty()`` slot."""
    is_complete = pct >= 100
    bar_color = COLOR_GREEN if is_complete else COLOR_AMBER if pct > 50 else COLOR_CYAN
    dot_class = "pulse-dot complete" if is_complete else "pulse-dot"
    fill_class = "progress-fill" if is_complete else "progress-fill working"
    slot.markdown(
        f"""
    <div class="progress-card">
        <div class="progress-label">
            <span class="{dot_class}"></span>{label}
        </div>
        {f'<div class="progress-sub">{sub}</div>' if sub else ''}
        <div class="progress-track">
            <div class="{fill_class}" style="width:{pct}%;background:{bar_color};box-shadow:0 0 10px {bar_color};"></div>
        </div>
        <div class="progress-pct">{pct}%</div>
    </div>
    """,
        unsafe_allow_html=True,
    )


def apply_chart_theme(fig) -> None:
    """Apply the Obsidian Quant Terminal theme to a Plotly figure (mutates in place)."""
    fig.update_layout(**chart_layout())
    style_axes(fig)
